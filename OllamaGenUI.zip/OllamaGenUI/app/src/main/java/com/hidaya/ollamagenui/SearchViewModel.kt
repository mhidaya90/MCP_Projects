package com.hidaya.ollamagenui

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class SearchViewModel : ViewModel() {

    private val client = OkHttpClient()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    private val _jsonResult = MutableStateFlow<JSONObject?>(null)
    val jsonResult: StateFlow<JSONObject?> = _jsonResult

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun onQueryChange(newQuery: String) {
        _query.value = newQuery
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun onSearch() {
        val q = _query.value.trim()
        if (q.isEmpty()) return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                _isLoading.value = true
                _error.value = null
                val json = callOllama(q)
                Log.i("SearchViewModel", "JSON result: ${json.toString()}")
                _jsonResult.value = json
            } catch (e: Exception) {
                _error.value = e.message ?: "Unknown error"
            } finally {
                _isLoading.value = false
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun callOllama(query: String): JSONObject {
//        val prompt = """
//            You are a JSON generator.
//            Return ONLY valid JSON with this exact structure:
//            {
//              "title": "string",
//              "items": [
//                { "label": "string", "description": "string" }
//              ]
//            }
//            Generate weather information for the city: "$query"
//        """.trimIndent()
        val today = LocalDate.now().toString()
        val prompt = """ 
            Return ONLY valid JSON. 
            Do not include markdown, code fences, explanations, or text outside the JSON.
            Always return a COMPLETE JSON object.
            
            Today's date is: $today
            
            Use this exact structure:
            {
                "title": "string",
                "items": [
                    { "label": "string", "description": "string" }
                ]
            }   
            Generate content for query: "$query"
        """.trimIndent()
//              "model": "gemma3:12b",
        val bodyJson = """
            {

              "model": "gemma3:27b",
              "prompt": ${JSONObject.quote(prompt)},
              "stream": false
            }
        """.trimIndent()

        val requestBody = bodyJson.toRequestBody("application/json".toMediaType())
        Log.i("SearchViewModel", "Response: ${BuildConfig.OLLAMA_API_KEY}")

        val request = Request.Builder()
            .url("https://ollama.com/api/generate")
            .addHeader("Authorization", "Bearer ${BuildConfig.OLLAMA_API_KEY}")
            .post(requestBody)
            .build()
        Log.i("SearchViewModel", "Request: $request")

        val call = client.newCall(request).execute()
        call.use { res ->
            if (!res.isSuccessful) {
                throw IllegalStateException("HTTP ${res.code}")
            }
            val responseBody = res.body?.string()
                ?: throw IllegalStateException("Empty body")
            val root = JSONObject(responseBody) // The actual JSON returned by the model is inside "response"
            val content = root.getString("response")
            val cleaned = content
                .replace("```json", "")
                .replace("```", "")
                .trim()

            println("RAW OLLAMA RESPONSE: $cleaned")

            return try{JSONObject(cleaned)}
            catch (e: Exception){
                throw IllegalStateException("Model returned invalid JSON:\n$cleaned")
            }
        }
//        return call.execute().use { response ->
//            if (!response.isSuccessful) {
//                Log.i("SearchViewModel", "Response: $response")
//
//                throw IllegalStateException("HTTP ${response.code}")
//            }
//            Log.i("SearchViewModel", "Response: ${response.body.toString()}")
//            val responseBody = response.body?.string()
//                ?: throw IllegalStateException("Empty body")
//            val root = JSONObject(responseBody)
//            val content = root
//                .getJSONArray("choices")
//                .getJSONObject(0)
//                .getJSONObject("message")
//                .getString("content")
//            JSONObject(content)
//        }
//        val response = client.newCall(request).execute()
//        if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
//
//        val responseBody = response.body?.string() ?: throw IllegalStateException("Empty body")
//
//        // Adjust this parsing to match your actual Ollama response format
//        val root = JSONObject(responseBody)
//        val content = root
//            .getJSONArray("choices")
//            .getJSONObject(0)
//            .getJSONObject("message")
//            .getString("content")
//
//        return JSONObject(content)
    }
}
