package com.hidaya.ollamagenui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreenContent(viewModel: SearchViewModel) {
    val query by viewModel.query.collectAsState()
    val jsonResult by viewModel.jsonResult.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val error by viewModel.error.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ollama Generative UI") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.onQueryChange(it) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Type your query…") },
                singleLine = true
            )

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = { viewModel.onSearch() },
                enabled = !isLoading && query.isNotBlank()
            ) {
                Text(if (isLoading) "Loading..." else "Search")
            }

            Spacer(Modifier.height(16.dp))

            error?.let {
                Text(text = it, color = Color.Red)
            }

            jsonResult?.let { json ->
                GeneratedContentView(json)
            }
        }
    }
}

@Composable
fun GeneratedContentView(json: JSONObject) {
    val title = json.optString("title", "Results")
    val itemsArray = json.optJSONArray("items") ?: JSONArray()

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            items((0 until itemsArray.length()).toList()) { index ->
                val item = itemsArray.getJSONObject(index)
                GeneratedItemCard(item)
            }
        }
    }
}

@Composable
fun GeneratedItemCard(item: JSONObject) {
    val label = item.optString("label", "Item")
    val description = item.optString("description", "")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = label, style = MaterialTheme.typography.titleMedium)
            if (description.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(text = description, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
