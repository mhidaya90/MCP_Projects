# 🚀 Android Studio Setup & Run Guide

## 📋 Prerequisites

Before opening the project in Android Studio, ensure you have:

### 1. **Android Studio** (Latest Version)
- Download from: https://developer.android.com/studio
- Minimum: Flamingo | 2022.2.1 or later

### 2. **Android SDK Components**
- **SDK Version 33** (Android 13)
- Build Tools 33.0.0+
- Android Emulator
- Virtual Device for testing

### 3. **Java Development Kit (JDK)**
- JDK 11 or later (included with Android Studio)

### 4. **Backend Server Running**
```bash
# Ensure backend is running on port 9000
curl http://localhost:9000/api/health
# Should return: {"status":"Server is running"}
```

---

## 📱 Step-by-Step Setup

### Step 1: Open Project in Android Studio

1. **Launch Android Studio**
2. Click **File** → **Open**
3. Navigate to: `/Users/hidaya/AI-Learnings/LearningPOC-7/supermarket-app/android`
4. Click **Open**
5. Wait for Gradle sync to complete (may take 2-3 minutes on first load)

### Step 2: Configure Android SDK

1. Go to **Android Studio** → **Preferences** (or **Settings** on Windows/Linux)
2. Navigate to **Languages & Frameworks** → **Android SDK**
3. Verify the following are installed:
   - ✅ Android SDK 33
   - ✅ Android SDK Build-Tools 33.x.x
   - ✅ Android Emulator
   - ✅ Android SDK Platform-Tools

4. Click **Apply** → **OK**

### Step 3: Create Android Virtual Device (Emulator)

1. In Android Studio, click **Tools** → **Device Manager**
2. Click **Create device**
3. Select a device profile:
   - Recommended: **Pixel 5** or **Pixel 6**
4. Click **Next**
5. Select **API 33** (Android 13)
6. Click **Next** → **Finish**

**Or create from menu:** Tools → Device Manager → Create Virtual Device

### Step 4: Configure Project Settings

The project is pre-configured, but verify:

**File:** `android/local.properties`
```properties
sdk.dir=/Users/hidaya/Library/Android/sdk
```

If this file doesn't exist or has wrong path:
1. Go to **Android Studio** → **Preferences** → **Android SDK**
2. Copy the SDK Location path
3. Create/update `local.properties` with correct path

---

## 🏗️ Build & Run the App

### Option A: Build from Android Studio (Recommended)

1. **Connect Backend Server** (ensure port 9000 is running)
   ```bash
   # In terminal, verify backend is running
   curl http://localhost:9000/api/products
   ```

2. **Sync Gradle Files**
   - Click **File** → **Sync Now**
   - Or press `Ctrl+Alt+Y` / `Cmd+Shift+Y`

3. **Build the Project**
   - Click **Build** → **Make Project**
   - Or press `Ctrl+F9` / `Cmd+F9`
   - Wait for build to complete (green checkmark appears)

4. **Run the App**
   - Click **Run** → **Run 'app'**
   - Or press `Shift+F10` / `Ctrl+R`
   - Select your virtual device
   - Click **OK**

5. **App launches** on emulator (first time may take 30-60 seconds)

---

## 📲 Testing the App

### Launch Screen
- **App Name:** Supermarket App
- **First Screen:** Login/Register Activity

### Test Login Flow

#### Option 1: Register New Account
```
Email: test@example.com
Password: Test123!
Full Name: Test User
Phone: 1234567890
Address: 123 Main St
```

#### Option 2: Use Test Credentials (if seeded)
```
Email: user@example.com
Password: password123
```

### Test Product Listing
1. **Login** with credentials above
2. **View Products** - Should show 6 products:
   - Fresh Apples - $5.99
   - Milk Carton - $3.29
   - Whole Wheat Bread - $2.99
   - Chicken Breast - $8.99
   - Broccoli - $3.49
   - Orange Juice - $4.99

3. **Add to Cart** - Click on any product → Select quantity → Add
4. **View Cart** - See added items with total
5. **Checkout** - Process order
6. **Payment** - Complete transaction

---

## 🔧 Project Configuration Details

### Main Activity Structure
```
MainActivity.java
├── ProductListingActivity
├── ProductDetailActivity
├── CartActivity
├── CheckoutActivity
├── LoginActivity
├── OTPVerificationActivity
└── OrderHistoryActivity
```

### API Configuration
**File:** `android/app/src/main/java/com/supermarket/api/RetrofitClient.java`

```java
private static final String BASE_URL = "http://10.0.2.2:9000";
// http://10.0.2.2 = localhost (for Android emulator)
// :9000 = Backend port
```

### Permissions
**File:** `android/app/src/main/AndroidManifest.xml`

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

---

## 🛠️ Troubleshooting

### Issue: Gradle Sync Fails
**Solution:**
1. Click **File** → **Sync Now**
2. If still fails: **File** → **Invalidate Caches** → **Invalidate and Restart**
3. Delete `.gradle` folder and rebuild

```bash
cd /Users/hidaya/AI-Learnings/LearningPOC-7/supermarket-app/android
rm -rf .gradle build
```

### Issue: App Crashes on Startup
**Check:**
1. **Backend is running:**
   ```bash
   curl http://localhost:9000/api/health
   ```

2. **View logs:** Click **Logcat** at bottom of Android Studio
   - Filter: `supermarket` to see app logs

3. **Check network permissions:** Manifest has internet permission

### Issue: Cannot Connect to Backend
**Verify:**
1. Emulator can reach host:
   ```bash
   # In emulator's adb shell
   ping 10.0.2.2
   ```

2. Backend port is 9000 (not 5000):
   ```bash
   lsof -i :9000
   ```

3. Check RetrofitClient.java uses correct URL

### Issue: Products Not Loading
1. **Backend API test:**
   ```bash
   curl http://localhost:9000/api/products
   ```
   Should return product list

2. **Check app logs** for network errors

3. **Verify database:** 
   ```bash
   psql -U hidaya -d supermarket_db -c "SELECT COUNT(*) FROM products;"
   ```

---

## 🔄 Running on Physical Device

### Enable USB Debugging
1. Go to **Settings** → **About Phone**
2. Tap **Build Number** 7 times
3. Go to **Settings** → **Developer Options**
4. Enable **USB Debugging**
5. Connect phone via USB to Mac

### Build & Run
1. In Android Studio, select your phone from device dropdown
2. Click **Run** → **Run 'app'**
3. App installs on phone

---

## 📊 Build Variants & Configuration

### Current Configuration
```
compileSdkVersion: 33
targetSdkVersion: 33
minSdkVersion: 21
```

### Build Types
- **Debug:** For development/testing
- **Release:** For production (requires signing)

### View Build Variants
- Click **View** → **Tool Windows** → **Build Variants**
- Select **debug** for testing

---

## ⚡ Essential Keyboard Shortcuts

| Action | Mac | Windows/Linux |
|--------|-----|----------------|
| Build | `Cmd+F9` | `Ctrl+F9` |
| Run | `Ctrl+R` | `Shift+F10` |
| Debug | `Ctrl+D` | `Shift+F9` |
| Sync Gradle | `Cmd+Shift+Y` | `Ctrl+Alt+Y` |
| Logcat | `Cmd+6` | `Alt+6` |
| Device Manager | `Cmd+Shift+Q` | `Ctrl+Shift+Q` |

---

## ✅ Verification Checklist

Before testing, verify:

- [ ] Android Studio installed
- [ ] Android SDK 33 installed
- [ ] Virtual Device created
- [ ] Backend server running on port 9000
- [ ] Can verify backend: `curl http://localhost:9000/api/health`
- [ ] Project opened in Android Studio
- [ ] Gradle sync completed successfully
- [ ] Build successful (no red errors)
- [ ] Emulator started and ready

---

## 📚 Additional Resources

### API Documentation
Location: `/Users/hidaya/AI-Learnings/LearningPOC-7/supermarket-app/API_DOCUMENTATION.md`

### Backend Setup
Location: `/Users/hidaya/AI-Learnings/LearningPOC-7/supermarket-app/backend`
- To restart: `npm run dev` or `node src/index.js`

### Database Access
```bash
psql -U hidaya -d supermarket_db

# View products
SELECT * FROM products;

# View users
SELECT * FROM users;

# View orders
SELECT * FROM orders;
```

---

## 🎯 Quick Start Command

```bash
# 1. Ensure backend is running
cd /Users/hidaya/AI-Learnings/LearningPOC-7/supermarket-app/backend
node src/index.js

# 2. In another terminal, verify it's up
curl http://localhost:9000/api/health

# 3. Open project in Android Studio (separate action)
open -a "Android Studio" /Users/hidaya/AI-Learnings/LearningPOC-7/supermarket-app/android

# 4. In Android Studio:
# - File → Sync Now
# - Run → Run 'app'
# - Select emulator
```

---

**You're all set! Happy coding! 🚀**
