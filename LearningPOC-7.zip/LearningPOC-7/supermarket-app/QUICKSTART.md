# ⚡ Quick Start - 10 Minutes to Live App

## Step 1: Backend (5 minutes)

### 1.1 Install & Setup
```bash
# Navigate to backend
cd supermarket-app/backend

# Install dependencies
npm install

# Create database (PostgreSQL must be running)
createdb supermarket_db

# Run migrations (creates tables + seeds data)
npm run migrate
```

### 1.2 Start Server
```bash
npm run dev
```

**Expected Output:**
```
Supermarket backend server running on port 5000
```

---

## Step 2: Android (3 minutes)

### 2.1 Open in Android Studio
```
File → Open → Select supermarket-app/android folder
```

### 2.2 Run App
- Click ▶️ **Run** button
- Select emulator or device
- Wait for app to load

### 2.3 Test Login
- Phone: `+12345678900` (any valid format)
- OTP: Check backend console for the printed OTP
- Tap "Verify"

---

## Step 3: Test Features (2 minutes)

### Browse Products
- See 6 sample products pre-loaded
- Search for items
- Filter by category

### Add to Cart
- Click "Add" on any product
- Items go to local cart

### Checkout
- Go to Cart → Checkout
- Enter delivery address
- Review total

### Payment
- Select payment method
- Process payment (80% success)
- See order confirmation

### View Orders
- Go to Profile → View Orders
- See all completed orders

---

## 🔧 Configuration

### If Backend Won't Start
```bash
# Check PostgreSQL is running
brew services start postgresql  # macOS
sudo service postgresql start   # Linux

# Or check if port 5000 is free
lsof -i :5000
```

### If Android Can't Connect
**In Android Studio:**
1. Open `RetrofitClient.java`
2. Find: `private static final String BASE_URL`
3. For Emulator: `http://10.0.2.2:5000` (default)
4. For Device: `http://<YOUR_IP>:5000`

### If OTP Not Working
- Check **backend console** for printed OTP
- Copy exact 6-digit OTP
- OTP expires in 10 minutes

---

## 🧪 Quick API Test

```bash
# Check if backend is running
curl http://localhost:5000/api/health

# Get all products
curl http://localhost:5000/api/products

# Send OTP
curl -X POST http://localhost:5000/api/auth/send-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber":"+1234567890"}'
```

---

## 📱 Demo User Flow

```
1. Launch App
   ↓
2. Enter Phone Number → Send OTP
   ↓
3. Check Backend Console for OTP
   ↓
4. Enter OTP → Verify
   ↓
5. Browse Products (6 samples available)
   ↓
6. Add Items to Cart
   ↓
7. Go to Checkout
   ↓
8. Enter Delivery Address
   ↓
9. Process Payment
   ↓
10. View Order History
```

---

## 📊 Sample Products

| Product | Price | Category |
|---------|-------|----------|
| Fresh Apples | $5.99 | Fruits |
| Milk Carton | $3.29 | Dairy |
| Whole Wheat Bread | $2.99 | Bakery |
| Chicken Breast | $8.99 | Meat |
| Broccoli | $3.49 | Vegetables |
| Orange Juice | $4.99 | Beverages |

---

## ⚙️ Environment Setup

### Backend .env (Already Configured)
```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=supermarket_db
DB_USER=postgres
DB_PASSWORD=postgres
JWT_SECRET=supermarket_secret_key_2026
PORT=5000
```

### Android API Config (Already Set)
```java
BASE_URL = "http://10.0.2.2:5000"  // Emulator
```

---

## 🚨 Troubleshooting

| Issue | Solution |
|-------|----------|
| `Connection refused` | Start PostgreSQL: `brew services start postgresql` |
| `Port 5000 in use` | Kill process: `lsof -i :5000` then `kill -9 <PID>` |
| `Database error` | Run: `npm run migrate` again |
| `Android can't connect` | Update BASE_URL in RetrofitClient.java |
| `OTP fails` | Check backend console for generated OTP |
| `Gradle sync fails` | Close & reopen Android Studio |

---

## 🎯 What Works

✅ User authentication (phone + OTP)  
✅ Product listing & search  
✅ Shopping cart  
✅ Order creation  
✅ Payment processing  
✅ Order history  
✅ User profiles  

---

## 📚 Full Documentation

- **README.md** - Complete overview
- **SETUP.md** - Detailed setup
- **API_DOCUMENTATION.md** - All endpoints
- **PROJECT_SUMMARY.md** - Project stats

---

## 💡 Pro Tips

1. **Keep terminal windows open** - One for backend, monitor logs
2. **Check console logs** - Backend prints OTP there
3. **Use Android emulator** - Easier IP configuration
4. **Test endpoints** - Use cURL before Android
5. **Save images** - Picasso caches images automatically

---

## 🎉 You're All Set!

Your supermarket app is running with:
- ✅ Full-featured Android app
- ✅ Production-ready backend
- ✅ PostgreSQL database
- ✅ API integration
- ✅ Phone authentication
- ✅ Payment processing
- ✅ Order management

**Start the backend, launch the app, and shop!** 🛍️

---

**Need Help?** Check the detailed documentation files in the project root.
