# Setup & Deployment Guide

## 🎯 Quick Start

### Step 1: Backend Server

```bash
# Navigate to backend
cd supermarket-app/backend

# Install dependencies
npm install

# Create PostgreSQL database
createdb supermarket_db

# Run migrations (creates tables and seeds data)
npm run migrate

# Start server
npm run dev
```

**Expected Output**:
```
Supermarket backend server running on port 5000
Users table created successfully
Products table created successfully
Orders tables created successfully
Sample products inserted successfully
```

---

### Step 2: Android App

#### Option A: Using Android Studio

1. Open Android Studio
2. File → Open → Select `supermarket-app/android`
3. Wait for Gradle sync to complete
4. Click ▶️ Run

#### Option B: Using Command Line

```bash
cd supermarket-app/android
./gradlew build          # Build the app
./gradlew installDebug   # Install on emulator/device
```

---

## 🔌 Network Configuration

### For Android Emulator (Android Studio)
- Backend URL: `http://10.0.2.2:5000`
- This is the default in `RetrofitClient.java`

### For Physical Device
1. Find your computer's IP: `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
2. Update `RetrofitClient.java`:
   ```java
   private static final String BASE_URL = "http://<your-IP>:5000";
   ```

---

## 🧪 Testing the App

### Demo Login Credentials
- Phone: Any valid format (e.g., +1234567890 or 1234567890)
- OTP: Check backend console (printed automatically)
  - Example: `OTP for +1234567890: 123456`

### Sample Products Available
1. Fresh Apples - $5.99
2. Milk Carton - $3.29
3. Whole Wheat Bread - $2.99
4. Chicken Breast - $8.99
5. Broccoli - $3.49
6. Orange Juice - $4.99

### Test Workflow
1. **Login**: Send OTP → Verify with backend console OTP
2. **Browse**: View products, search, filter by category
3. **Shop**: Add items to cart
4. **Checkout**: Enter delivery address
5. **Pay**: Select payment method (payment has 80% success rate)
6. **Order History**: View completed orders

---

## 📊 API Testing

### Quick Test with cURL

```bash
# Health check
curl http://localhost:5000/api/health

# Get all products
curl http://localhost:5000/api/products

# Send OTP
curl -X POST http://localhost:5000/api/auth/send-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber":"+1234567890"}'

# Verify OTP (use the OTP from backend console)
curl -X POST http://localhost:5000/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber":"+1234567890","otp":"123456"}'
```

---

## ⚙️ Configuration Files

### Backend `.env`
```
PORT=5000
NODE_ENV=development
DB_HOST=localhost
DB_PORT=5432
DB_NAME=supermarket_db
DB_USER=postgres
DB_PASSWORD=postgres
JWT_SECRET=supermarket_secret_key_2026
JWT_EXPIRE=7d
APP_NAME=Supermarket App
```

### Android `RetrofitClient.java`
```java
// Line ~10 - Update this for your network
private static final String BASE_URL = "http://10.0.2.2:5000";
```

---

## 🛠️ Database Management

### PostgreSQL Commands

```bash
# Connect to database
psql -U postgres -d supermarket_db

# View tables
\dt

# View users
SELECT * FROM users;

# View products
SELECT * FROM products;

# View orders
SELECT * FROM orders;

# Drop database (if needed to restart)
dropdb supermarket_db
```

---

## 🔍 Common Issues & Solutions

### 1. Backend won't start
**Error**: `Error: connect ECONNREFUSED 127.0.0.1:5432`
- **Solution**: Start PostgreSQL service
  ```bash
  # macOS
  brew services start postgresql
  
  # Windows
  # Start PostgreSQL from Services
  
  # Linux
  sudo service postgresql start
  ```

### 2. Android app can't connect to backend
**Error**: `Connection refused` or `Timeout`
- **Check**: 
  - Is backend running on port 5000?
  - Is the BASE_URL correct in RetrofitClient.java?
  - Are firewall settings allowing port 5000?
  - Is app configured to use correct IP?

### 3. OTP login not working
**Error**: `Invalid OTP`
- **Solution**: 
  - Check backend console for the generated OTP
  - Copy exact OTP value
  - OTP expires in 10 minutes

### 4. PostgreSQL already initialized
- **Solution**: Drop and recreate
  ```bash
  dropdb supermarket_db
  createdb supermarket_db
  npm run migrate
  ```

---

## 📱 App Navigation Flow

```
Login Screen
    ↓
OTP Verification
    ↓
Product Listing (Home)
    ├── View Products
    ├── Search Products
    ├── Filter by Category
    ├── Cart Button → Shopping Cart
    └── Profile Button → User Profile
        
Shopping Cart
    ├── View/Edit Items
    ├── Update Quantities
    └── Checkout Button
        
Checkout
    ├── Enter Delivery Address
    ├── Review Total
    └── Place Order
        
Payment
    ├── Select Payment Method
    ├── Process Payment
    └── Order History

User Profile
    ├── View Profile
    ├── Edit Details
    ├── View Orders
    └── Logout
```

---

## 📈 Performance Tips

- **First run**: Allow time for Gradle sync and APK build
- **Emulator**: Use hardware acceleration if available
- **Database**: Migrations run automatically on first backend start
- **Images**: Picasso caches images automatically

---

## 🚀 Deployment Checklist

- [ ] PostgreSQL running locally
- [ ] Backend dependencies installed (`npm install`)
- [ ] Database migrations completed (`npm run migrate`)
- [ ] Backend server running (`npm run dev`)
- [ ] Android project synced in Android Studio
- [ ] Gradle build successful
- [ ] Emulator running or device connected
- [ ] Backend URL verified in RetrofitClient.java
- [ ] App installed and running on device
- [ ] Test login with valid phone + OTP

---

## 📞 Support

For issues:
1. Check the Troubleshooting section above
2. Verify all environment variables are set
3. Check database connectivity
4. Review backend console for errors
5. Check Android Logcat for app errors

---

**Last Updated**: February 2026
