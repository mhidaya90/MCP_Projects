# API Documentation - Supermarket Backend

## Base URL
```
http://localhost:5000
```

## Authentication
All protected endpoints require:
```
Authorization: Bearer <JWT_TOKEN>
```

---

## 🔐 Auth Endpoints

### 1. Send OTP
Request OTP for login via phone number

**Endpoint:** `POST /api/auth/send-otp`

**Body:**
```json
{
  "phoneNumber": "+1234567890"
}
```

**Response (200):**
```json
{
  "message": "OTP sent successfully",
  "otp": "123456"  // For demo only, remove in production
}
```

---

### 2. Verify OTP
Verify OTP and get authentication token

**Endpoint:** `POST /api/auth/verify-otp`

**Body:**
```json
{
  "phoneNumber": "+1234567890",
  "otp": "123456"
}
```

**Response (200):**
```json
{
  "message": "OTP verified successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "phoneNumber": "+1234567890",
    "firstName": "John",
    "lastName": "Doe",
    "email": "john@example.com"
  }
}
```

---

### 3. Get Profile
Get current user profile

**Endpoint:** `GET /api/auth/profile`

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "message": "Profile fetched successfully",
  "user": {
    "id": 1,
    "phoneNumber": "+1234567890",
    "firstName": "John",
    "lastName": "Doe",
    "email": "john@example.com",
    "address": "123 Main Street"
  }
}
```

---

### 4. Update Profile
Update user profile information

**Endpoint:** `PUT /api/auth/profile`

**Headers:**
```
Authorization: Bearer <token>
Content-Type: application/json
```

**Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "address": "123 Main Street, City"
}
```

**Response (200):**
```json
{
  "message": "Profile updated successfully",
  "user": {
    "id": 1,
    "phoneNumber": "+1234567890",
    "firstName": "John",
    "lastName": "Doe",
    "email": "john@example.com",
    "address": "123 Main Street, City"
  }
}
```

---

## 🛍️ Product Endpoints

### 1. Get All Products
Get list of all available products

**Endpoint:** `GET /api/products?limit=50&offset=0`

**Query Parameters:**
- `limit` (optional, default: 50) - Number of products to fetch
- `offset` (optional, default: 0) - Number of products to skip

**Response (200):**
```json
{
  "message": "Products fetched successfully",
  "data": [
    {
      "id": 1,
      "name": "Fresh Apples",
      "description": "Organic red apples",
      "price": 5.99,
      "stock_quantity": 100,
      "category": "Fruits",
      "image_url": "https://...",
      "rating": 4.5,
      "is_available": true
    }
  ],
  "pagination": {
    "limit": 50,
    "offset": 0
  }
}
```

---

### 2. Get Product by ID
Get details of a specific product

**Endpoint:** `GET /api/products/:id`

**Path Parameters:**
- `id` - Product ID

**Response (200):**
```json
{
  "message": "Product fetched successfully",
  "data": {
    "id": 1,
    "name": "Fresh Apples",
    "description": "Organic red apples",
    "price": 5.99,
    "stock_quantity": 100,
    "category": "Fruits",
    "image_url": "https://...",
    "rating": 4.5,
    "is_available": true
  }
}
```

---

### 3. Get Products by Category
Get products filtered by category

**Endpoint:** `GET /api/products/category/:category?limit=50&offset=0`

**Path Parameters:**
- `category` - Category name (e.g., "Fruits", "Dairy")

**Query Parameters:**
- `limit` (optional, default: 50)
- `offset` (optional, default: 0)

**Response (200):**
```json
{
  "message": "Products by category fetched successfully",
  "data": [...]
}
```

---

### 4. Search Products
Search products by name

**Endpoint:** `GET /api/products/search?q=<query>&limit=50`

**Query Parameters:**
- `q` (required) - Search term
- `limit` (optional, default: 50)

**Response (200):**
```json
{
  "message": "Search results",
  "data": [...]
}
```

---

## 📦 Order Endpoints

### 1. Create Order
Create a new order

**Endpoint:** `POST /api/orders`

**Headers:**
```
Authorization: Bearer <token>
Content-Type: application/json
```

**Body:**
```json
{
  "items": [
    {
      "productId": 1,
      "quantity": 2,
      "unitPrice": 5.99
    }
  ],
  "deliveryAddress": "123 Main Street, City, State"
}
```

**Response (201):**
```json
{
  "message": "Order created successfully",
  "data": {
    "id": 1,
    "userId": 1,
    "totalAmount": 11.98,
    "status": "pending",
    "paymentStatus": "pending"
  }
}
```

---

### 2. Get User Orders
Get all orders for the current user

**Endpoint:** `GET /api/orders?limit=50&offset=0`

**Headers:**
```
Authorization: Bearer <token>
```

**Query Parameters:**
- `limit` (optional, default: 50)
- `offset` (optional, default: 0)

**Response (200):**
```json
{
  "message": "User orders fetched successfully",
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "total_amount": 11.98,
      "status": "pending",
      "payment_status": "pending",
      "delivery_address": "123 Main Street",
      "items": [
        {
          "id": 1,
          "product_id": 1,
          "quantity": 2,
          "unit_price": 5.99,
          "total_price": 11.98
        }
      ]
    }
  ]
}
```

---

### 3. Get Order by ID
Get details of a specific order

**Endpoint:** `GET /api/orders/:orderId`

**Headers:**
```
Authorization: Bearer <token>
```

**Path Parameters:**
- `orderId` - Order ID

**Response (200):**
```json
{
  "message": "Order fetched successfully",
  "data": {
    "id": 1,
    "user_id": 1,
    "total_amount": 11.98,
    "status": "pending",
    "payment_status": "pending",
    "items": [...]
  }
}
```

---

### 4. Update Order Status
Update status of an order

**Endpoint:** `PUT /api/orders/:orderId/status`

**Headers:**
```
Authorization: Bearer <token>
Content-Type: application/json
```

**Body:**
```json
{
  "status": "confirmed"
}
```

**Response (200):**
```json
{
  "message": "Order status updated",
  "data": {
    "id": 1,
    "status": "confirmed"
  }
}
```

---

## 💳 Payment Endpoints

### 1. Process Payment
Process payment for an order

**Endpoint:** `POST /api/payments/process`

**Headers:**
```
Authorization: Bearer <token>
Content-Type: application/json
```

**Body:**
```json
{
  "orderId": 1,
  "amount": 11.98,
  "paymentMethod": "Credit Card"
}
```

**Response (200 or 400):**
```json
{
  "message": "Payment successful",
  "transactionId": "TXN-1644950400000",
  "status": "success",
  "orderId": 1,
  "amount": 11.98
}
```

**Failed Response:**
```json
{
  "message": "Payment failed",
  "status": "failed",
  "orderId": 1,
  "amount": 11.98
}
```

---

### 2. Get Payment Status
Get payment status of an order

**Endpoint:** `GET /api/payments/:orderId/status`

**Headers:**
```
Authorization: Bearer <token>
```

**Path Parameters:**
- `orderId` - Order ID

**Response (200):**
```json
{
  "orderId": 1,
  "paymentStatus": "completed",
  "totalAmount": 11.98
}
```

---

## 🏥 Health Check

### Health Check
Check if backend server is running

**Endpoint:** `GET /api/health`

**Response (200):**
```json
{
  "status": "Server is running"
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "error": "Invalid request parameters"
}
```

### 401 Unauthorized
```json
{
  "error": "Access token required"
}
```

### 403 Forbidden
```json
{
  "error": "Invalid or expired token"
}
```

### 404 Not Found
```json
{
  "error": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal server error"
}
```

---

## 📝 Notes

- All timestamps are in ISO 8601 format
- Phone numbers should include country code (e.g., +1 for US)
- OTP is valid for 10 minutes
- JWT tokens expire in 7 days
- Payment has 80% success rate in demo mode
- Images are loaded from Picasso (can be any HTTPS URL)

---

**Last Updated**: February 2026
