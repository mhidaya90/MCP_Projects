package com.supermarket.models;

import com.google.gson.annotations.SerializedName;

public class Order {
    public int id;
    public int user_id;
    public double total_amount;
    public String status;
    public String payment_status;
    public String delivery_address;
    public String created_at;

    @SerializedName("items")
    public OrderItem[] items;

    public Order() {}

    public Order(int user_id, double total_amount, String delivery_address) {
        this.user_id = user_id;
        this.total_amount = total_amount;
        this.delivery_address = delivery_address;
        this.status = "pending";
        this.payment_status = "pending";
    }

    public static class OrderItem {
        public int id;
        public int product_id;
        public int quantity;
        public double unit_price;
        public double total_price;
    }
}
