package com.supermarket.utils;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.supermarket.models.CartItem;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static final String CART_PREF = "cart_preferences";
    private static final String CART_ITEMS = "cart_items";

    private SharedPreferences sharedPreferences;
    private Gson gson;

    public CartManager(Context context) {
        this.sharedPreferences = context.getSharedPreferences(CART_PREF, Context.MODE_PRIVATE);
        this.gson = new Gson();
    }

    public void addItem(CartItem item) {
        List<CartItem> items = getAllItems();
        
        // Check if item already exists
        for (CartItem existingItem : items) {
            if (existingItem.productId == item.productId) {
                existingItem.quantity += item.quantity;
                saveItems(items);
                return;
            }
        }
        
        items.add(item);
        saveItems(items);
    }

    public void removeItem(int productId) {
        List<CartItem> items = getAllItems();
        items.removeIf(item -> item.productId == productId);
        saveItems(items);
    }

    public void updateQuantity(int productId, int quantity) {
        List<CartItem> items = getAllItems();
        for (CartItem item : items) {
            if (item.productId == productId) {
                item.quantity = quantity;
                if (quantity <= 0) {
                    removeItem(productId);
                } else {
                    saveItems(items);
                }
                return;
            }
        }
    }

    public List<CartItem> getAllItems() {
        String json = sharedPreferences.getString(CART_ITEMS, "[]");
        CartItem[] items = gson.fromJson(json, CartItem[].class);
        List<CartItem> itemList = new ArrayList<>();
        for (CartItem item : items) {
            itemList.add(item);
        }
        return itemList;
    }

    public double getTotalPrice() {
        double total = 0;
        for (CartItem item : getAllItems()) {
            total += item.getTotalPrice();
        }
        return total;
    }

    public int getTotalItems() {
        return getAllItems().size();
    }

    public void clearCart() {
        sharedPreferences.edit().putString(CART_ITEMS, "[]").apply();
    }

    private void saveItems(List<CartItem> items) {
        String json = gson.toJson(items);
        sharedPreferences.edit().putString(CART_ITEMS, json).apply();
    }
}
