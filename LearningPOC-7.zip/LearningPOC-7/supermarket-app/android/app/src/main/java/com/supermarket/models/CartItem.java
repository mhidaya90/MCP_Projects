package com.supermarket.models;

public class CartItem {
    public int productId;
    public String productName;
    public double price;
    public int quantity;
    public String imageUrl;

    public CartItem() {}

    public CartItem(int productId, String productName, double price, 
                    int quantity, String imageUrl) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
        this.imageUrl = imageUrl;
    }

    public double getTotalPrice() {
        return price * quantity;
    }
}
