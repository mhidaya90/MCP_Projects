package com.supermarket;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.supermarket.ui.LoginActivity;
import com.supermarket.ui.ProductListingActivity;
import com.supermarket.utils.SessionManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SessionManager sessionManager = new SessionManager(this);

        // Check if user is already logged in
        if (sessionManager.isLoggedIn()) {
            // User is logged in, go to product listing
            startActivity(new Intent(MainActivity.this, ProductListingActivity.class));
        } else {
            // User is not logged in, go to login
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
        }

        finish();
    }
}
