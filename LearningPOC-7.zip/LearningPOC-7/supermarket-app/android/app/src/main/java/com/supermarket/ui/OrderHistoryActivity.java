package com.supermarket.ui;

import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.supermarket.R;
import com.supermarket.api.ApiService;
import com.supermarket.api.RetrofitClient;
import com.supermarket.models.Order;
import com.supermarket.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrderHistoryActivity extends AppCompatActivity {
    private RecyclerView ordersRecyclerView;
    private ProgressBar progressBar;
    private ApiService apiService;
    private SessionManager sessionManager;
    private List<Order> orders = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        ordersRecyclerView = findViewById(R.id.ordersRecyclerView);
        progressBar = findViewById(R.id.progressBar);

        apiService = RetrofitClient.getApiService();
        sessionManager = new SessionManager(this);

        ordersRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadOrders();
    }

    private void loadOrders() {
        progressBar.setVisibility(android.view.View.VISIBLE);

        String token = "Bearer " + sessionManager.getAuthToken();

        apiService.getUserOrders(token, 50, 0).enqueue(new Callback<ApiService.OrderListResponse>() {
            @Override
            public void onResponse(Call<ApiService.OrderListResponse> call, Response<ApiService.OrderListResponse> response) {
                progressBar.setVisibility(android.view.View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    orders = response.body().data;
                    Toast.makeText(OrderHistoryActivity.this, 
                        "Loaded " + orders.size() + " orders", Toast.LENGTH_SHORT).show();
                    // TODO: Create OrderAdapter and set it to RecyclerView
                    OrderAdapter adapter = new OrderAdapter(OrderHistoryActivity.this, orders);
                    ordersRecyclerView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<ApiService.OrderListResponse> call, Throwable t) {
                progressBar.setVisibility(android.view.View.GONE);
                Toast.makeText(OrderHistoryActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
