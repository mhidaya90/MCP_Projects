package com.supermarket.ui;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.supermarket.R;
import com.supermarket.models.CartItem;
import com.supermarket.models.Product;
import com.supermarket.utils.CartManager;
import com.squareup.picasso.Picasso;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    private List<Product> products;
    private Context context;
    private CartManager cartManager;

    public ProductAdapter(Context context, List<Product> products) {
        this.context = context;
        this.products = products;
        this.cartManager = new CartManager(context);
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = products.get(position);

        holder.productName.setText(product.name);
        holder.productDescription.setText(product.description);
        holder.productPrice.setText(String.format("$%.2f", product.price));
        holder.productStock.setText("Stock: " + product.stock_quantity);

        // Load image
        if (product.image_url != null && !product.image_url.isEmpty()) {
            Picasso.get().load(product.image_url)
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_menu_close_clear_cancel)
                    .into(holder.productImage);
        }

        holder.addToCartButton.setOnClickListener(v -> {
            CartItem cartItem = new CartItem(
                    product.id,
                    product.name,
                    product.price,
                    1,
                    product.image_url
            );
            cartManager.addItem(cartItem);
            holder.addToCartButton.setText("Added ✓");
            holder.addToCartButton.setEnabled(false);
        });

        holder.viewDetailsButton.setOnClickListener(v -> {
            Log.d("ProductAdapter", "View details button clicked for product: " + product.name);

            // Start ProductDetailActivity with the product ID as an extra ("productId")
            Intent intent = new Intent(context, ProductDetailActivity.class);
            intent.putExtra("productId", product.id);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    public static class ProductViewHolder extends RecyclerView.ViewHolder {
        ImageView productImage;
        TextView productName, productDescription, productPrice, productStock;
        Button addToCartButton, viewDetailsButton;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.productImage);
            productName = itemView.findViewById(R.id.productName);
            productDescription = itemView.findViewById(R.id.productDescription);
            productPrice = itemView.findViewById(R.id.productPrice);
            productStock = itemView.findViewById(R.id.productStock);
            addToCartButton = itemView.findViewById(R.id.addToCartButton);
            viewDetailsButton = itemView.findViewById(R.id.viewDetailsButton);
        }
    }
}
