package com.supermarket.api;

import android.util.Log;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    private static final String TAG = "RetrofitClient";
    private static Retrofit retrofit = null;
    private static final String BASE_URL = "http://10.0.2.2:9000"; // For Android emulator

    public static Retrofit getClient() {
        if (retrofit == null) {
            Log.d(TAG, "Creating Retrofit instance with BASE_URL: " + BASE_URL);
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            Log.d(TAG, "Retrofit instance created successfully");
        } else {
            Log.d(TAG, "Returning existing Retrofit instance");
        }
        return retrofit;
    }

    public static ApiService getApiService() {
        Log.d(TAG, "getApiService() called");
        Retrofit client = getClient();
        ApiService service = client.create(ApiService.class);
        Log.d(TAG, "ApiService created: " + (service != null ? "TRUE" : "FALSE"));
        return service;
    }
}
