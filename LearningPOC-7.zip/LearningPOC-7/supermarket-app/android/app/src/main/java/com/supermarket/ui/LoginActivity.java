package com.supermarket.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.supermarket.R;
import com.supermarket.api.ApiService;
import com.supermarket.api.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";
    private EditText phoneNumberInput;
    private Button sendOTPButton;
    private ProgressBar progressBar;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate() called");
        setContentView(R.layout.activity_login);

        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        sendOTPButton = findViewById(R.id.sendOTPButton);
        progressBar = findViewById(R.id.progressBar);

        apiService = RetrofitClient.getApiService();
        Log.d(TAG, "API Service initialized: " + (apiService != null ? "TRUE" : "FALSE"));

        sendOTPButton.setOnClickListener(v -> {
            Log.d(TAG, "Send OTP button clicked");
            sendOTP();
        });
    }

    private void sendOTP() {
        String phoneNumber = phoneNumberInput.getText().toString().trim();
        Log.d(TAG, "sendOTP() called with phone: " + phoneNumber);

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter phone number", Toast.LENGTH_SHORT).show();
            Log.w(TAG, "Phone number is empty");
            return;
        }

        progressBar.setVisibility(android.view.View.VISIBLE);

        ApiService.OTPRequest request = new ApiService.OTPRequest();
        request.phoneNumber = phoneNumber;

        Log.d(TAG, "Making API call to sendOTP");
        apiService.sendOTP(request).enqueue(new Callback<ApiService.OTPResponse>() {
            @Override
            public void onResponse(Call<ApiService.OTPResponse> call, Response<ApiService.OTPResponse> response) {
                Log.d(TAG, "onResponse() called");
                Log.d(TAG, "Response code: " + response.code());
                Log.d(TAG, "Response successful: " + response.isSuccessful());
                
                progressBar.setVisibility(android.view.View.GONE);

                if (response.isSuccessful()) {
                    Log.d(TAG, "OTP sent successfully");
                    Toast.makeText(LoginActivity.this, "OTP sent successfully", Toast.LENGTH_SHORT).show();
                    
                    Intent intent = new Intent(LoginActivity.this, OTPVerificationActivity.class);
                    intent.putExtra("phoneNumber", phoneNumber);
                    startActivity(intent);
                } else {
                    Log.e(TAG, "Failed to send OTP. Response: " + response.errorBody());
                    Toast.makeText(LoginActivity.this, "Failed to send OTP", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiService.OTPResponse> call, Throwable t) {
                Log.e(TAG, "onFailure() called - API call failed");
                Log.e(TAG, "Error message: " + t.getMessage());
                Log.e(TAG, "Error type: " + t.getClass().getSimpleName());
                t.printStackTrace();
                
                progressBar.setVisibility(android.view.View.GONE);
                Toast.makeText(LoginActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
