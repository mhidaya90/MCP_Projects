package com.supermarket.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.supermarket.MainActivity;
import com.supermarket.R;
import com.supermarket.utils.SessionManager;

public class ProfileActivity extends AppCompatActivity {
    private TextView profileName;
    private TextView profileEmail;
    private TextView profilePhone;
    private Button logoutButton;
    private Button viewOrdersButton;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profileName = findViewById(R.id.firstNameInput);
        profileEmail = findViewById(R.id.emailInput);
        profilePhone = findViewById(R.id.addressInput);
        logoutButton = findViewById(R.id.logoutButton);
        viewOrdersButton = findViewById(R.id.ordersButton);

        sessionManager = new SessionManager(this);

        // Load user profile data
        loadUserProfile();

        // Logout button click
        logoutButton.setOnClickListener(v -> {
            sessionManager.logout();
            startActivity(new Intent(ProfileActivity.this, LoginActivity.class));
            finish();
        });

        // View orders button click
        viewOrdersButton.setOnClickListener(v -> {
            startActivity(new Intent(ProfileActivity.this, OrderHistoryActivity.class));
        });
    }

    private void loadUserProfile() {
        String userName = sessionManager.getUserName();
        String userPhone = sessionManager.getPhoneNumber();

        profileName.setText("Name: " + (userName != null ? userName : "N/A"));
        profilePhone.setText("Phone: " + (userPhone != null ? userPhone : "N/A"));
    }
}
