package com.supermarket.ui;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.supermarket.R;
import com.supermarket.models.Order;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {
    private List<Order> orders;
    private Context context;

    public OrderAdapter(Context context, List<Order> orders) {
        this.context = context;
        this.orders = orders;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);

        holder.orderId.setText("Order #" + order.id);
        holder.orderAmount.setText(String.format("Amount: $%.2f", order.total_amount));
        holder.orderStatus.setText("Status: " + order.status);
        holder.paymentStatus.setText("Payment: " + order.payment_status);
        holder.orderDate.setText("Date: " + (order.created_at != null ? order.created_at : "N/A"));

        holder.viewDetailsButton.setOnClickListener(v -> {
            Intent intent = new Intent(context, ProductDetailActivity.class);
            intent.putExtra("orderId", order.id);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView orderId, orderAmount, orderStatus, paymentStatus, orderDate;
        Button viewDetailsButton;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            orderId = itemView.findViewById(R.id.orderId);
            orderAmount = itemView.findViewById(R.id.orderAmount);
            orderStatus = itemView.findViewById(R.id.orderStatus);
            paymentStatus = itemView.findViewById(R.id.paymentStatus);
            orderDate = itemView.findViewById(R.id.orderDate);
            viewDetailsButton = itemView.findViewById(R.id.viewDetailsButton);
        }
    }
}
