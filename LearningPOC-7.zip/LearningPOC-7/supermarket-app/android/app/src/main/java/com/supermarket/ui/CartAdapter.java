package com.supermarket.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.supermarket.R;
import com.supermarket.models.CartItem;
import com.supermarket.utils.CartManager;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {
    private List<CartItem> cartItems;
    private Context context;
    private CartManager cartManager;

    public CartAdapter(Context context, List<CartItem> cartItems) {
        this.context = context;
        this.cartItems = cartItems;
        this.cartManager = new CartManager(context);
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItems.get(position);

        holder.itemName.setText(item.productName);
        holder.itemPrice.setText(String.format("$%.2f", item.price));
        holder.itemQuantity.setText(String.valueOf(item.quantity));
        holder.itemTotal.setText(String.format("Total: $%.2f", item.getTotalPrice()));

        // Load image
        if (item.imageUrl != null && !item.imageUrl.isEmpty()) {
            Picasso.get().load(item.imageUrl)
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_menu_close_clear_cancel)
                    .into(holder.itemImage);
        }

        holder.decreaseButton.setOnClickListener(v -> {
            int newQuantity = item.quantity - 1;
            if (newQuantity <= 0) {
                cartManager.removeItem(item.productId);
                cartItems.remove(position);
                notifyItemRemoved(position);
            } else {
                cartManager.updateQuantity(item.productId, newQuantity);
                item.quantity = newQuantity;
                notifyItemChanged(position);
            }
        });

        holder.increaseButton.setOnClickListener(v -> {
            int newQuantity = item.quantity + 1;
            cartManager.updateQuantity(item.productId, newQuantity);
            item.quantity = newQuantity;
            notifyItemChanged(position);
        });

        holder.removeButton.setOnClickListener(v -> {
            cartManager.removeItem(item.productId);
            cartItems.remove(position);
            notifyItemRemoved(position);
        });
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {
        ImageView itemImage;
        TextView itemName, itemPrice, itemQuantity, itemTotal;
        Button decreaseButton, increaseButton, removeButton;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            itemImage = itemView.findViewById(R.id.itemImage);
            itemName = itemView.findViewById(R.id.itemName);
            itemPrice = itemView.findViewById(R.id.itemPrice);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            itemTotal = itemView.findViewById(R.id.itemTotal);
            decreaseButton = itemView.findViewById(R.id.decreaseButton);
            increaseButton = itemView.findViewById(R.id.increaseButton);
            removeButton = itemView.findViewById(R.id.removeButton);
        }
    }
}
