package com.supermarket.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.supermarket.R;
import com.supermarket.api.ApiService;
import com.supermarket.api.RetrofitClient;
import com.supermarket.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OTPVerificationActivity extends AppCompatActivity {
    private EditText otpInput;
    private Button verifyButton;
    private ProgressBar progressBar;
    private String phoneNumber;
    private ApiService apiService;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);

        otpInput = findViewById(R.id.otpInput);
        verifyButton = findViewById(R.id.verifyButton);
        progressBar = findViewById(R.id.progressBar);

        phoneNumber = getIntent().getStringExtra("phoneNumber");
        apiService = RetrofitClient.getApiService();
        sessionManager = new SessionManager(this);

        verifyButton.setOnClickListener(v -> verifyOTP());
    }

    private void verifyOTP() {
        String otp = otpInput.getText().toString().trim();

        if (otp.isEmpty()) {
            Toast.makeText(this, "Please enter OTP", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(android.view.View.VISIBLE);

        ApiService.OTPVerifyRequest request = new ApiService.OTPVerifyRequest();
        request.phoneNumber = phoneNumber;
        request.otp = otp;

        apiService.verifyOTP(request).enqueue(new Callback<ApiService.AuthResponse>() {
            @Override
            public void onResponse(Call<ApiService.AuthResponse> call, Response<ApiService.AuthResponse> response) {
                progressBar.setVisibility(android.view.View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    sessionManager.saveAuthToken(response.body().token);
                    sessionManager.saveUserData(
                        response.body().user.id,
                        response.body().user.phoneNumber,
                        response.body().user.firstName
                    );

                    Toast.makeText(OTPVerificationActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(OTPVerificationActivity.this, ProductListingActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(OTPVerificationActivity.this, "Invalid OTP", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiService.AuthResponse> call, Throwable t) {
                progressBar.setVisibility(android.view.View.GONE);
                Toast.makeText(OTPVerificationActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
