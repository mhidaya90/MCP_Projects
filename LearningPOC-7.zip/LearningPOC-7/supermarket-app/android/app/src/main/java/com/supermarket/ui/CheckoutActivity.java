package com.supermarket.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.supermarket.R;
import com.supermarket.api.ApiService;
import com.supermarket.api.RetrofitClient;
import com.supermarket.models.CartItem;
import com.supermarket.utils.CartManager;
import com.supermarket.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckoutActivity extends AppCompatActivity {
    private TextView totalPriceView;
    private EditText deliveryAddressInput;
    private Button placeOrderButton;
    private ProgressBar progressBar;
    private CartManager cartManager;
    private SessionManager sessionManager;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        totalPriceView = findViewById(R.id.totalPriceView);
        deliveryAddressInput = findViewById(R.id.deliveryAddressInput);
        placeOrderButton = findViewById(R.id.placeOrderButton);
        progressBar = findViewById(R.id.progressBar);

        cartManager = new CartManager(this);
        sessionManager = new SessionManager(this);
        apiService = RetrofitClient.getApiService();

        totalPriceView.setText(String.format("Total: $%.2f", cartManager.getTotalPrice()));

        placeOrderButton.setOnClickListener(v -> placeOrder());
    }

    private void placeOrder() {
        String deliveryAddress = deliveryAddressInput.getText().toString().trim();

        if (deliveryAddress.isEmpty()) {
            Toast.makeText(this, "Please enter delivery address", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(android.view.View.VISIBLE);

        List<CartItem> cartItems = cartManager.getAllItems();
        List<ApiService.OrderItemRequest> items = new ArrayList<>();

        for (CartItem item : cartItems) {
            ApiService.OrderItemRequest itemRequest = new ApiService.OrderItemRequest();
            itemRequest.productId = item.productId;
            itemRequest.quantity = item.quantity;
            itemRequest.unitPrice = item.price;
            items.add(itemRequest);
        }

        ApiService.CreateOrderRequest orderRequest = new ApiService.CreateOrderRequest();
        orderRequest.items = items;
        orderRequest.deliveryAddress = deliveryAddress;

        String token = "Bearer " + sessionManager.getAuthToken();

        apiService.createOrder(token, orderRequest).enqueue(new Callback<ApiService.OrderResponse>() {
            @Override
            public void onResponse(Call<ApiService.OrderResponse> call, Response<ApiService.OrderResponse> response) {
                progressBar.setVisibility(android.view.View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    Toast.makeText(CheckoutActivity.this, "Order placed successfully", Toast.LENGTH_SHORT).show();
                    
                    // Proceed to payment
                    Intent intent = new Intent(CheckoutActivity.this, PaymentActivity.class);
                    intent.putExtra("orderId", response.body().data.id);
                    intent.putExtra("totalAmount", response.body().data.total_amount);
                    startActivity(intent);
                    
                    cartManager.clearCart();
                    finish();
                } else {
                    Toast.makeText(CheckoutActivity.this, "Failed to place order", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiService.OrderResponse> call, Throwable t) {
                progressBar.setVisibility(android.view.View.GONE);
                Toast.makeText(CheckoutActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
