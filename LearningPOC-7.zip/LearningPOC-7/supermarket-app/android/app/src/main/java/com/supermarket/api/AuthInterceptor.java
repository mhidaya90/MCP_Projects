package com.supermarket.api;

import android.content.Context;
import android.util.Log;

import com.supermarket.utils.SessionManager;
import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class AuthInterceptor implements Interceptor {
    private static final String TAG = "AuthInterceptor";
    private Context context;

    public AuthInterceptor(Context context) {
        this.context = context;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request originalRequest = chain.request();
        Log.d(TAG, "Intercepting request: " + originalRequest.url());

        // Get token from SessionManager
        SessionManager sessionManager = new SessionManager(context);
        String token = sessionManager.getAuthToken();

        Log.d(TAG, "Token exists: " + (token != null ? "YES" : "NO"));
        
        // If token exists, add it to the request
        if (token != null) {
            Log.d(TAG, "Adding Authorization header with token");
            Request newRequest = originalRequest.newBuilder()
                    .header("Authorization", "Bearer " + token)
                    .build();
            Log.d(TAG, "Request sent with auth header");
            return chain.proceed(newRequest);
        } else {
            Log.w(TAG, "No token found, sending request without auth header");
        }

        return chain.proceed(originalRequest);
    }
}
