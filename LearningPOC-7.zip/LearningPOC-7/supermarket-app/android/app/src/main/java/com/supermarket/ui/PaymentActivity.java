package com.supermarket.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.supermarket.R;
import com.supermarket.api.ApiService;
import com.supermarket.api.RetrofitClient;
import com.supermarket.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PaymentActivity extends AppCompatActivity {
    private TextView orderIdView, amountView;
    private Spinner paymentMethodSpinner;
    private Button payButton;
    private ProgressBar progressBar;
    private int orderId;
    private double totalAmount;
    private ApiService apiService;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        orderIdView = findViewById(R.id.orderIdView);
        amountView = findViewById(R.id.amountView);
        paymentMethodSpinner = findViewById(R.id.paymentMethodSpinner);
        payButton = findViewById(R.id.payButton);
        progressBar = findViewById(R.id.progressBar);

        apiService = RetrofitClient.getApiService();
        sessionManager = new SessionManager(this);

        orderId = getIntent().getIntExtra("orderId", 0);
        totalAmount = getIntent().getDoubleExtra("totalAmount", 0);

        orderIdView.setText("Order #" + orderId);
        amountView.setText(String.format("Amount: $%.2f", totalAmount));

        payButton.setOnClickListener(v -> processPayment());
    }

    private void processPayment() {
        progressBar.setVisibility(android.view.View.VISIBLE);

        String paymentMethod = paymentMethodSpinner.getSelectedItem().toString();

        ApiService.PaymentRequest request = new ApiService.PaymentRequest();
        request.orderId = orderId;
        request.amount = totalAmount;
        request.paymentMethod = paymentMethod;

        String token = "Bearer " + sessionManager.getAuthToken();

        apiService.processPayment(token, request).enqueue(new Callback<ApiService.PaymentResponse>() {
            @Override
            public void onResponse(Call<ApiService.PaymentResponse> call, Response<ApiService.PaymentResponse> response) {
                progressBar.setVisibility(android.view.View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    if ("success".equals(response.body().status)) {
                        Toast.makeText(PaymentActivity.this, "Payment successful!", Toast.LENGTH_SHORT).show();
                        
                        Intent intent = new Intent(PaymentActivity.this, OrderHistoryActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(PaymentActivity.this, "Payment failed", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(PaymentActivity.this, "Payment processing failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiService.PaymentResponse> call, Throwable t) {
                progressBar.setVisibility(android.view.View.GONE);
                Toast.makeText(PaymentActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
