package com.supermarket.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.supermarket.R;
import com.supermarket.models.CartItem;
import com.supermarket.utils.CartManager;

import java.util.List;

public class CartActivity extends AppCompatActivity {
    private RecyclerView cartRecyclerView;
    private Button checkoutButton;
    private ProgressBar progressBar;
    private CartManager cartManager;
    private List<CartItem> cartItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        cartRecyclerView = findViewById(R.id.cartRecyclerView);
        checkoutButton = findViewById(R.id.checkoutButton);
        progressBar = findViewById(R.id.progressBar);

        cartManager = new CartManager(this);
        cartRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        checkoutButton.setOnClickListener(v -> proceedToCheckout());

        loadCart();
    }

    private void loadCart() {
        cartItems = cartManager.getAllItems();
        if (cartItems.isEmpty()) {
            Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show();
        }
        // TODO: Create CartAdapter and set it to RecyclerView
        // Create and set ProductAdapter
        CartAdapter adapter = new CartAdapter(CartActivity.this, cartItems);
        cartRecyclerView.setAdapter(adapter);

    }

    private void proceedToCheckout() {
        if (cartItems.isEmpty()) {
            Toast.makeText(this, "Add items to cart first", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(new android.content.Intent(this, CheckoutActivity.class));
    }
}
