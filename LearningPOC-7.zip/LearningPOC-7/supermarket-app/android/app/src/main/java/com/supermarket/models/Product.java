package com.supermarket.models;

public class Product {
    public int id;
    public String name;
    public String description;
    public double price;
    public int stock_quantity;
    public String category;
    public String image_url;
    public double rating;
    public boolean is_available;

    public Product() {}

    public Product(int id, String name, String description, double price, 
                   int stock_quantity, String category, String image_url) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.stock_quantity = stock_quantity;
        this.category = category;
        this.image_url = image_url;
    }
}
