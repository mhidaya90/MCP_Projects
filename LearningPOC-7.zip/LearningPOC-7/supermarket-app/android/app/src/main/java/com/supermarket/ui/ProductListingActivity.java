package com.supermarket.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.supermarket.R;
import com.supermarket.api.ApiService;
import com.supermarket.api.RetrofitClient;
import com.supermarket.models.Product;
import com.supermarket.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductListingActivity extends AppCompatActivity {
    private static final String TAG = "ProductListingActivity";
    private RecyclerView productsRecyclerView;
    private ProgressBar progressBar;
    private Button cartButton, profileButton;
    private ApiService apiService;
    private SessionManager sessionManager;
    private List<Product> products = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate() called");
        setContentView(R.layout.activity_product_listing);

        productsRecyclerView = findViewById(R.id.productsRecyclerView);
        progressBar = findViewById(R.id.progressBar);
        cartButton = findViewById(R.id.cartButton);
        profileButton = findViewById(R.id.profileButton);

        apiService = RetrofitClient.getApiService();
        sessionManager = new SessionManager(this);

        Log.d(TAG, "API Service initialized: " + (apiService != null ? "TRUE" : "FALSE"));
        Log.d(TAG, "SessionManager initialized: " + (sessionManager != null ? "TRUE" : "FALSE"));

        productsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        cartButton.setOnClickListener(v -> {
            Log.d(TAG, "Cart button clicked");
            startActivity(new Intent(this, CartActivity.class));
        });
        
        profileButton.setOnClickListener(v -> {
            Log.d(TAG, "Profile button clicked");
            startActivity(new Intent(this, ProfileActivity.class));
        });

        loadProducts();
    }

    private void loadProducts() {
        Log.d(TAG, "loadProducts() called");
        progressBar.setVisibility(android.view.View.VISIBLE);

        Log.d(TAG, "Making API call to getProducts(50, 0)");
        apiService.getProducts(50, 0).enqueue(new Callback<ApiService.ProductListResponse>() {
            @Override
            public void onResponse(Call<ApiService.ProductListResponse> call, Response<ApiService.ProductListResponse> response) {
                Log.d(TAG, "onResponse() called");
                Log.d(TAG, "Response code: " + response.code());
                Log.d(TAG, "Response successful: " + response.isSuccessful());
                
                progressBar.setVisibility(android.view.View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    products = response.body().data;
                    Log.d(TAG, "Products received: " + products.size());
                    Log.d(TAG, "Response message: " + response.body().message);
                    
                    // Create and set ProductAdapter
                    ProductAdapter adapter = new ProductAdapter(ProductListingActivity.this, products);
                    productsRecyclerView.setAdapter(adapter);
                    Log.d(TAG, "ProductAdapter set to RecyclerView");
                    
                    Toast.makeText(ProductListingActivity.this, 
                        "Loaded " + products.size() + " products", Toast.LENGTH_SHORT).show();
                } else {
                    Log.e(TAG, "Response not successful or body is null");
                    Log.e(TAG, "Response body: " + (response.body() != null ? response.body().toString() : "null"));
                }
            }

            @Override
            public void onFailure(Call<ApiService.ProductListResponse> call, Throwable t) {
                Log.e(TAG, "onFailure() called - API call failed");
                Log.e(TAG, "Error message: " + t.getMessage());
                Log.e(TAG, "Error type: " + t.getClass().getSimpleName());
                t.printStackTrace();
                
                progressBar.setVisibility(android.view.View.GONE);
                Toast.makeText(ProductListingActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
