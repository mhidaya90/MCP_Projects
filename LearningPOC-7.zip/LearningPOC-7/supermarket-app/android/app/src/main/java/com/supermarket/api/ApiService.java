package com.supermarket.api;

import com.supermarket.models.Order;
import com.supermarket.models.Product;
import com.supermarket.models.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {
    // Auth endpoints
    @POST("/api/auth/send-otp")
    Call<OTPResponse> sendOTP(@Body OTPRequest request);

    @POST("/api/auth/verify-otp")
    Call<AuthResponse> verifyOTP(@Body OTPVerifyRequest request);

    @GET("/api/auth/profile")
    Call<UserResponse> getProfile(@Header("Authorization") String token);

    @PUT("/api/auth/profile")
    Call<UserResponse> updateProfile(
        @Header("Authorization") String token,
        @Body ProfileUpdateRequest request
    );

    // Product endpoints
    @GET("/api/products")
    Call<ProductListResponse> getProducts(
        @Query("limit") int limit,
        @Query("offset") int offset
    );

    @GET("/api/products/{id}")
    Call<ProductResponse> getProductById(@Path("id") int id);

    @GET("/api/products/category/{category}")
    Call<ProductListResponse> getProductsByCategory(
        @Path("category") String category,
        @Query("limit") int limit,
        @Query("offset") int offset
    );

    @GET("/api/products/search")
    Call<ProductListResponse> searchProducts(@Query("q") String query);

    // Order endpoints
    @POST("/api/orders")
    Call<OrderResponse> createOrder(
        @Header("Authorization") String token,
        @Body CreateOrderRequest request
    );

    @GET("/api/orders")
    Call<OrderListResponse> getUserOrders(
        @Header("Authorization") String token,
        @Query("limit") int limit,
        @Query("offset") int offset
    );

    @GET("/api/orders/{orderId}")
    Call<OrderResponse> getOrderById(
        @Header("Authorization") String token,
        @Path("orderId") int orderId
    );

    // Payment endpoints
    @POST("/api/payments/process")
    Call<PaymentResponse> processPayment(
        @Header("Authorization") String token,
        @Body PaymentRequest request
    );

    @GET("/api/payments/{orderId}/status")
    Call<PaymentStatusResponse> getPaymentStatus(
        @Header("Authorization") String token,
        @Path("orderId") int orderId
    );

    // Health check
    @GET("/api/health")
    Call<HealthResponse> checkHealth();

    // Request/Response models
    class OTPRequest {
        public String phoneNumber;
    }

    class OTPResponse {
        public String message;
        public String otp; // For demo only
    }

    class OTPVerifyRequest {
        public String phoneNumber;
        public String otp;
    }

    class AuthResponse {
        public String message;
        public String token;
        public User user;
    }

    class UserResponse {
        public String message;
        public User user;
    }

    class ProfileUpdateRequest {
        public String firstName;
        public String lastName;
        public String email;
        public String address;
    }

    class ProductResponse {
        public String message;
        public Product data;
    }

    class ProductListResponse {
        public String message;
        public List<Product> data;
        public Pagination pagination;
    }

    class OrderResponse {
        public String message;
        public Order data;
    }

    class OrderListResponse {
        public String message;
        public List<Order> data;
    }

    class CreateOrderRequest {
        public List<OrderItemRequest> items;
        public String deliveryAddress;
    }

    class OrderItemRequest {
        public int productId;
        public int quantity;
        public double unitPrice;
    }

    class PaymentRequest {
        public int orderId;
        public double amount;
        public String paymentMethod;
    }

    class PaymentResponse {
        public String message;
        public String transactionId;
        public String status;
        public int orderId;
        public double amount;
    }

    class PaymentStatusResponse {
        public int orderId;
        public String paymentStatus;
        public double totalAmount;
    }

    class HealthResponse {
        public String status;
    }

    class Pagination {
        public int limit;
        public int offset;
    }
}
