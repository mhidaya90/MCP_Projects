package com.supermarket.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.supermarket.R;
import com.supermarket.api.ApiService;
import com.supermarket.api.RetrofitClient;
import com.supermarket.ui.LoginActivity;
import com.supermarket.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {
    private EditText firstNameInput, lastNameInput, emailInput, addressInput;
    private Button updateButton, logoutButton, ordersButton;
    private ProgressBar progressBar;
    private ApiService apiService;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        firstNameInput = findViewById(R.id.firstNameInput);
        lastNameInput = findViewById(R.id.lastNameInput);
        emailInput = findViewById(R.id.emailInput);
        addressInput = findViewById(R.id.addressInput);
        updateButton = findViewById(R.id.updateButton);
        logoutButton = findViewById(R.id.logoutButton);
        ordersButton = findViewById(R.id.ordersButton);
        progressBar = findViewById(R.id.progressBar);

        apiService = RetrofitClient.getApiService();
        sessionManager = new SessionManager(this);

        updateButton.setOnClickListener(v -> updateProfile());
        logoutButton.setOnClickListener(v -> logout());
        ordersButton.setOnClickListener(v -> startActivity(new Intent(this, OrderHistoryActivity.class)));

        loadProfile();
    }

    private void loadProfile() {
        progressBar.setVisibility(android.view.View.VISIBLE);

        String token = "Bearer " + sessionManager.getAuthToken();

        apiService.getProfile(token).enqueue(new Callback<ApiService.UserResponse>() {
            @Override
            public void onResponse(Call<ApiService.UserResponse> call, Response<ApiService.UserResponse> response) {
                progressBar.setVisibility(android.view.View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    firstNameInput.setText(response.body().user.firstName != null ? response.body().user.firstName : "");
                    lastNameInput.setText(response.body().user.lastName != null ? response.body().user.lastName : "");
                    emailInput.setText(response.body().user.email != null ? response.body().user.email : "");
                    addressInput.setText(response.body().user.address != null ? response.body().user.address : "");
                }
            }

            @Override
            public void onFailure(Call<ApiService.UserResponse> call, Throwable t) {
                progressBar.setVisibility(android.view.View.GONE);
                Toast.makeText(ProductDetailActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateProfile() {
        progressBar.setVisibility(android.view.View.VISIBLE);

        ApiService.ProfileUpdateRequest request = new ApiService.ProfileUpdateRequest();
        request.firstName = firstNameInput.getText().toString().trim();
        request.lastName = lastNameInput.getText().toString().trim();
        request.email = emailInput.getText().toString().trim();
        request.address = addressInput.getText().toString().trim();

        String token = "Bearer " + sessionManager.getAuthToken();

        apiService.updateProfile(token, request).enqueue(new Callback<ApiService.UserResponse>() {
            @Override
            public void onResponse(Call<ApiService.UserResponse> call, Response<ApiService.UserResponse> response) {
                progressBar.setVisibility(android.view.View.GONE);

                if (response.isSuccessful()) {
                    Toast.makeText(ProductDetailActivity.this, "Profile updated successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ProductDetailActivity.this, "Failed to update profile", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiService.UserResponse> call, Throwable t) {
                progressBar.setVisibility(android.view.View.GONE);
                Toast.makeText(ProductDetailActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void logout() {
        sessionManager.logout();
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
