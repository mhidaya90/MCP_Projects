package com.supermarket.models;

public class User {
    public int id;
    public String phoneNumber;
    public String firstName;
    public String lastName;
    public String email;
    public String address;

    public User() {}

    public User(int id, String phoneNumber, String firstName, 
                String lastName, String email, String address) {
        this.id = id;
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.address = address;
    }
}
