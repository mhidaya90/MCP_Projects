# Supermarket App - Complete Project Documentation

## 📱 Project Overview

A complete supermarket shopping application with:
- **Android App** (Java) - Product listing, cart, orders, and payments
- **Node.js Backend** - RESTful API with phone-based authentication
- **PostgreSQL Database** - Data persistence

---

## 🏗️ Architecture

```
supermarket-app/
├── android/                  # Android Application
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── java/
│   │   │   │   └── com/supermarket/
│   │   │   │       ├── MainActivity.java
│   │   │   │       ├── api/                 # API service layer
│   │   │   │       ├── models/              # Data models
│   │   │   │       ├── ui/                  # Activity screens
│   │   │   │       └── utils/               # Utilities
│   │   │   └── res/
│   │   │       ├── layout/                  # UI layouts
│   │   │       └── values/                  # Resources
│   │   └── build.gradle
│   └── build.gradle
│
└── backend/                  # Node.js Backend
    ├── src/
    │   ├── config/          # Database config
    │   ├── controllers/      # Business logic
    │   ├── middleware/       # Auth middleware
    │   ├── models/           # Database models
    │   ├── routes/           # API routes
    │   ├── utils/            # Helper functions
    │   └── index.js          # Entry point
    ├── package.json
    ├── .env
    └── .env.example
```

---

## 🚀 Backend Setup

### Prerequisites
- Node.js (v14+)
- PostgreSQL (v12+)
- npm or yarn

### Installation

1. **Navigate to backend directory**
   ```bash
   cd supermarket-app/backend
   npm install
   ```

2. **Setup PostgreSQL Database**
   ```bash
   createdb supermarket_db
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env
   # Edit .env with your database credentials
   ```

4. **Run migrations**
   ```bash
   npm run migrate
   ```

5. **Start server**
   ```bash
   npm start        # Production
   npm run dev      # Development (with nodemon)
   ```

Server runs on `http://localhost:5000`

---

## 📱 Android Setup

### Prerequisites
- Android Studio (v4.2+)
- Android SDK (API 21+)
- Java JDK 11+

### Installation

1. **Open project in Android Studio**
   - File → Open → Select `android` folder

2. **Dependencies**
   - Gradle will auto-download dependencies from `app/build.gradle`
   - Key libraries:
     - Retrofit2 (HTTP client)
     - Picasso (Image loading)
     - AndroidX (Modern resources)

3. **Update Backend URL**
   - In `api/RetrofitClient.java`
   - Change `BASE_URL` to your backend server IP
   - For emulator: `http://10.0.2.2:5000`
   - For device: `http://<your-pc-ip>:5000`

4. **Build & Run**
   - Click "Run" or press `Ctrl+R` (Cmd+R on Mac)
   - Select emulator or device

---

## 📡 API Endpoints

### Authentication
- `POST /api/auth/send-otp` - Send OTP to phone
- `POST /api/auth/verify-otp` - Verify OTP and get token
- `GET /api/auth/profile` - Get user profile (requires token)
- `PUT /api/auth/profile` - Update profile (requires token)

### Products
- `GET /api/products` - List all products
- `GET /api/products/:id` - Get product details
- `GET /api/products/category/:category` - Filter by category
- `GET /api/products/search?q=<query>` - Search products

### Orders
- `POST /api/orders` - Create order (requires token)
- `GET /api/orders` - Get user's orders (requires token)
- `GET /api/orders/:orderId` - Get order details (requires token)
- `PUT /api/orders/:orderId/status` - Update order status (requires token)

### Payments
- `POST /api/payments/process` - Process payment (returns mock success/failure)
- `GET /api/payments/:orderId/status` - Check payment status (requires token)

---

## 🔐 Authentication Flow

1. **Login Screen**
   - User enters phone number
   - Backend sends OTP (mock - printed to console)

2. **OTP Verification**
   - User enters OTP
   - Backend validates (default demo OTP format: 6 digits)
   - JWT token issued after verification

3. **Protected Routes**
   - All subsequent requests include: `Authorization: Bearer <token>`
   - Token stored securely in encrypted SharedPreferences

---

## 🛒 Shopping Features

### Product Listing
- Fetch and display available products
- Search and filter by category
- Product details with pricing & availability

### Shopping Cart
- Add/remove items (LocalStorage via CartManager)
- Update quantities
- Calculate totals

### Checkout
- Enter delivery address
- Review order summary
- Confirm order placement

### Payment
- Select payment method
- Process payment (80% mock success rate for demo)
- Receive payment confirmation

### Order History
- View all previous orders
- Check order status
- Track delivery

---

## 📊 Database Schema

### Users Table
```sql
- id (PK)
- phone_number (UNIQUE)
- otp & otp_expires_at
- is_verified
- first_name, last_name
- email, address
- created_at, updated_at
```

### Products Table
```sql
- id (PK)
- name, description
- price
- stock_quantity
- category
- image_url
- rating, is_available
- created_at, updated_at
```

### Orders Table
```sql
- id (PK)
- user_id (FK)
- total_amount
- status, payment_status
- delivery_address
- created_at, updated_at
```

### Order Items Table
```sql
- id (PK)
- order_id (FK)
- product_id (FK)
- quantity, unit_price, total_price
```

---

## 🔧 Configuration

### Backend Environment Variables (.env)
```
PORT=5000
NODE_ENV=development
DB_HOST=localhost
DB_PORT=5432
DB_NAME=supermarket_db
DB_USER=postgres
DB_PASSWORD=postgres
JWT_SECRET=your_secret_key
JWT_EXPIRE=7d
```

### Android API Configuration (RetrofitClient.java)
```java
// For Emulator
private static final String BASE_URL = "http://10.0.2.2:5000";

// For Device
private static final String BASE_URL = "http://<your-ip>:5000";
```

---

## 🧪 Testing API

### Using cURL or Postman

**Send OTP**
```bash
curl -X POST http://localhost:5000/api/auth/send-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber":"+1234567890"}'
```

**Verify OTP**
```bash
curl -X POST http://localhost:5000/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber":"+1234567890","otp":"123456"}'
```

**Get Products**
```bash
curl http://localhost:5000/api/products
```

**Create Order** (requires token)
```bash
curl -X POST http://localhost:5000/api/orders \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "items": [{"productId":1,"quantity":2}],
    "deliveryAddress":"123 Main St"
  }'
```

---

## 📝 Sample Data

The database includes pre-seeded products:
- Fresh Apples ($5.99)
- Milk Carton ($3.29)
- Whole Wheat Bread ($2.99)
- Chicken Breast ($8.99)
- Broccoli ($3.49)
- Orange Juice ($4.99)

---

## 🐛 Troubleshooting

### Backend Issues
- **Port 5000 already in use**: Change PORT in .env
- **Database connection failed**: Verify PostgreSQL is running and credentials are correct
- **Tables not created**: Run `npm run migrate`

### Android Issues
- **Cannot connect to backend**: 
  - Check IP address in RetrofitClient.java
  - Ensure backend server is running
  - Verify firewall settings
- **OTP fails**: Check backend console for OTP value
- **Clear app data**: Android Studio → Device Manager → Wipe Data

---

## 📦 Dependencies

### Backend
- express (Web framework)
- pg (PostgreSQL client)
- jsonwebtoken (JWT auth)
- bcryptjs (Password hashing)
- dotenv (Environment variables)

### Android
- Retrofit2 (HTTP client)
- Gson (JSON parsing)
- Picasso (Image loading)
- AndroidX (Modern APIs)
- Material Design (UI components)

---

## 🎯 Next Steps for Production

1. **Security**
   - Implement real SMS OTP service (Twilio)
   - Add HTTPS/SSL certificates
   - Implement rate limiting
   - Add input validation & sanitization

2. **Payment Integration**
   - Integration with Stripe/PayPal API
   - PCI compliance
   - Transaction logging

3. **Features**
   - Real-time notifications
   - Order tracking
   - User reviews & ratings
   - Wishlist functionality

4. **Performance**
   - Add caching (Redis)
   - Implement pagination
   - Database indexing
   - API response compression

5. **Testing**
   - Unit tests
   - Integration tests
   - UI automation tests

---

## 📄 License

This project is for learning and demonstration purposes.

---

**Developed**: February 2026
**Version**: 1.0.0
