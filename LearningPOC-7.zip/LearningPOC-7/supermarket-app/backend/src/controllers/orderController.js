const Order = require('../models/Order');
const Product = require('../models/Product');

class OrderController {
  static async create(req, res) {
    try {
      const userId = req.user.id;
      const { items, deliveryAddress } = req.body;

      if (!items || items.length === 0) {
        return res.status(400).json({ error: 'Order must contain at least one item' });
      }

      if (!deliveryAddress) {
        return res.status(400).json({ error: 'Delivery address is required' });
      }

      // Calculate total and validate stock
      let totalAmount = 0;
      const processedItems = [];

      for (const item of items) {
        const product = await Product.getById(item.productId);

        if (!product) {
          return res.status(404).json({ error: `Product ${item.productId} not found` });
        }

        if (product.stock_quantity < item.quantity) {
          return res.status(400).json({ 
            error: `Insufficient stock for ${product.name}` 
          });
        }

        const itemTotal = product.price * item.quantity;
        totalAmount += itemTotal;

        processedItems.push({
          productId: item.productId,
          quantity: item.quantity,
          unitPrice: product.price,
          totalPrice: itemTotal
        });

        // Update product stock
        await Product.updateStock(item.productId, item.quantity);
      }

      const order = await Order.create(userId, processedItems, totalAmount, deliveryAddress);

      res.status(201).json({
        message: 'Order created successfully',
        data: {
          id: order.id,
          userId: order.user_id,
          totalAmount: order.total_amount,
          status: order.status,
          paymentStatus: order.payment_status
        }
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async getById(req, res) {
    try {
      const { orderId } = req.params;
      const userId = req.user.id;

      const order = await Order.getById(orderId);

      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }

      // Verify ownership
      if (order.user_id !== userId) {
        return res.status(403).json({ error: 'Unauthorized' });
      }

      res.json({
        message: 'Order fetched successfully',
        data: order
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async getByUserId(req, res) {
    try {
      const userId = req.user.id;
      const limit = parseInt(req.query.limit) || 50;
      const offset = parseInt(req.query.offset) || 0;

      const orders = await Order.getByUserId(userId, limit, offset);

      res.json({
        message: 'User orders fetched successfully',
        data: orders
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async updateStatus(req, res) {
    try {
      const { orderId } = req.params;
      const { status } = req.body;

      if (!status) {
        return res.status(400).json({ error: 'Status is required' });
      }

      const order = await Order.updateStatus(orderId, status);

      res.json({
        message: 'Order status updated',
        data: order
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
}

module.exports = OrderController;
