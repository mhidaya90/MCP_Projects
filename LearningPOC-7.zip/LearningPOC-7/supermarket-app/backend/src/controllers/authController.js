const User = require('../models/User');
const { generateOTP, generateToken, validatePhoneNumber } = require('../utils/helpers');

class AuthController {
  static async sendOTP(req, res) {
    try {
      const { phoneNumber } = req.body;

      if (!phoneNumber) {
        return res.status(400).json({ error: 'Phone number is required' });
      }

      if (!validatePhoneNumber(phoneNumber)) {
        return res.status(400).json({ error: 'Invalid phone number format' });
      }

      let user = await User.findByPhoneNumber(phoneNumber);
      if (!user) {
        user = await User.create(phoneNumber, '', '');
      }

      const otp = generateOTP();
      await User.updateOTP(phoneNumber, otp);

      // In a real app, send OTP via SMS
      console.log(`OTP for ${phoneNumber}: ${otp}`);

      res.json({
        message: 'OTP sent successfully',
        // For demo purposes only - remove in production
        otp: otp
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async verifyOTP(req, res) {
    try {
      const { phoneNumber, otp } = req.body;

      if (!phoneNumber || !otp) {
        return res.status(400).json({ error: 'Phone number and OTP are required' });
      }

      const user = await User.findByPhoneNumber(phoneNumber);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      if (user.otp !== otp) {
        return res.status(400).json({ error: 'Invalid OTP' });
      }

      if (new Date() > user.otp_expires_at) {
        return res.status(400).json({ error: 'OTP has expired' });
      }

      await User.verifyUser(phoneNumber);
      const token = generateToken(user.id, phoneNumber);

      res.json({
        message: 'OTP verified successfully',
        token,
        user: {
          id: user.id,
          phoneNumber: user.phone_number,
          firstName: user.first_name,
          lastName: user.last_name,
          email: user.email
        }
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async updateProfile(req, res) {
    try {
      const userId = req.user.id;
      const { firstName, lastName, email, address } = req.body;

      const user = await User.updateProfile(userId, firstName, lastName, email, address);

      res.json({
        message: 'Profile updated successfully',
        user: {
          id: user.id,
          phoneNumber: user.phone_number,
          firstName: user.first_name,
          lastName: user.last_name,
          email: user.email,
          address: user.address
        }
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async getProfile(req, res) {
    try {
      const userId = req.user.id;
      const user = await User.findById(userId);

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      res.json({
        user: {
          id: user.id,
          phoneNumber: user.phone_number,
          firstName: user.first_name,
          lastName: user.last_name,
          email: user.email,
          address: user.address
        }
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
}

module.exports = AuthController;
