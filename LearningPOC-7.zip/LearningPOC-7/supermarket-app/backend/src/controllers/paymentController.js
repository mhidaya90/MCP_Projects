const Order = require('../models/Order');

class PaymentController {
  // Mock payment processing
  static async processPayment(req, res) {
    try {
      const { orderId, amount, paymentMethod } = req.body;
      const userId = req.user.id;

      if (!orderId || !amount || !paymentMethod) {
        return res.status(400).json({ error: 'Order ID, amount, and payment method are required' });
      }

      const order = await Order.getById(orderId);

      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }

      if (order.user_id !== userId) {
        return res.status(403).json({ error: 'Unauthorized' });
      }

      if (order.payment_status === 'completed') {
        return res.status(400).json({ error: 'Order already paid' });
      }

      // Mock payment processing - randomly succeed or fail
      const isSuccessful = Math.random() > 0.2; // 80% success rate

      if (isSuccessful) {
        await Order.updatePaymentStatus(orderId, 'completed');
        await Order.updateStatus(orderId, 'confirmed');

        res.json({
          message: 'Payment successful',
          transactionId: `TXN-${Date.now()}`,
          status: 'success',
          orderId,
          amount
        });
      } else {
        res.status(400).json({
          message: 'Payment failed',
          status: 'failed',
          orderId,
          amount
        });
      }
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async getPaymentStatus(req, res) {
    try {
      const { orderId } = req.params;
      const userId = req.user.id;

      const order = await Order.getById(orderId);

      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }

      if (order.user_id !== userId) {
        return res.status(403).json({ error: 'Unauthorized' });
      }

      res.json({
        orderId,
        paymentStatus: order.payment_status,
        totalAmount: order.total_amount
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
}

module.exports = PaymentController;
