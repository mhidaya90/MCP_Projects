const Product = require('../models/Product');

class ProductController {
  static async getAll(req, res) {
    try {
      const limit = parseInt(req.query.limit) || 50;
      const offset = parseInt(req.query.offset) || 0;

      const products = await Product.getAll(limit, offset);
      res.json({
        message: 'Products fetched successfully',
        data: products,
        pagination: { limit, offset }
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async getByCategory(req, res) {
    try {
      const { category } = req.params;
      const limit = parseInt(req.query.limit) || 50;
      const offset = parseInt(req.query.offset) || 0;

      const products = await Product.getByCategory(category, limit, offset);
      res.json({
        message: 'Products by category fetched successfully',
        data: products
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;
      const product = await Product.getById(id);

      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }

      res.json({
        message: 'Product fetched successfully',
        data: product
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }

  static async search(req, res) {
    try {
      const { q } = req.query;
      const limit = parseInt(req.query.limit) || 50;

      if (!q) {
        return res.status(400).json({ error: 'Search query is required' });
      }

      const products = await Product.searchByName(q, limit);
      res.json({
        message: 'Search results',
        data: products
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
}

module.exports = ProductController;
