const express = require('express');
const ProductController = require('../controllers/productController');

const router = express.Router();

router.get('/', ProductController.getAll);
router.get('/search', ProductController.search);
router.get('/category/:category', ProductController.getByCategory);
router.get('/:id', ProductController.getById);

module.exports = router;
