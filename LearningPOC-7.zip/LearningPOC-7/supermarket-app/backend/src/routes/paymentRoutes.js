const express = require('express');
const PaymentController = require('../controllers/paymentController');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

router.post('/process', authenticateToken, PaymentController.processPayment);
router.get('/:orderId/status', authenticateToken, PaymentController.getPaymentStatus);

module.exports = router;
