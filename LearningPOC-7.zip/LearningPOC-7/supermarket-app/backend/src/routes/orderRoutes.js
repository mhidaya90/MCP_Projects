const express = require('express');
const OrderController = require('../controllers/orderController');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

router.post('/', authenticateToken, OrderController.create);
router.get('/', authenticateToken, OrderController.getByUserId);
router.get('/:orderId', authenticateToken, OrderController.getById);
router.put('/:orderId/status', authenticateToken, OrderController.updateStatus);

module.exports = router;
