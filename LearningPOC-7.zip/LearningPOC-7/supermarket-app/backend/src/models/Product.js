const pool = require('../config/database');

class Product {
  static async createTable() {
    const query = `
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        stock_quantity INTEGER DEFAULT 0,
        category VARCHAR(100),
        image_url VARCHAR(500),
        rating DECIMAL(3, 2) DEFAULT 0,
        is_available BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;
    const client = await pool.connect();
    try {
      await client.query(query);
      console.log('Products table created successfully');
    } catch (err) {
      console.error('Error creating products table:', err);
    } finally {
      client.release();
    }
  }

  static async getAll(limit = 50, offset = 0) {
    const query = `
      SELECT * FROM products 
      WHERE is_available = true
      ORDER BY created_at DESC
      LIMIT $1 OFFSET $2;
    `;
    try {
      const result = await pool.query(query, [limit, offset]);
      return result.rows;
    } catch (err) {
      throw new Error(`Error fetching products: ${err.message}`);
    }
  }

  static async getByCategory(category, limit = 50, offset = 0) {
    const query = `
      SELECT * FROM products 
      WHERE is_available = true AND category = $1
      ORDER BY created_at DESC
      LIMIT $2 OFFSET $3;
    `;
    try {
      const result = await pool.query(query, [category, limit, offset]);
      return result.rows;
    } catch (err) {
      throw new Error(`Error fetching products by category: ${err.message}`);
    }
  }

  static async getById(id) {
    const query = 'SELECT * FROM products WHERE id = $1;';
    try {
      const result = await pool.query(query, [id]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error fetching product: ${err.message}`);
    }
  }

  static async searchByName(searchTerm, limit = 50) {
    const query = `
      SELECT * FROM products 
      WHERE is_available = true AND name ILIKE $1
      ORDER BY created_at DESC
      LIMIT $2;
    `;
    try {
      const result = await pool.query(query, [`%${searchTerm}%`, limit]);
      return result.rows;
    } catch (err) {
      throw new Error(`Error searching products: ${err.message}`);
    }
  }

  static async create(name, description, price, stockQuantity, category, imageUrl) {
    const query = `
      INSERT INTO products (name, description, price, stock_quantity, category, image_url)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *;
    `;
    try {
      const result = await pool.query(query, [name, description, price, stockQuantity, category, imageUrl]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error creating product: ${err.message}`);
    }
  }

  static async updateStock(productId, quantity) {
    const query = `
      UPDATE products
      SET stock_quantity = stock_quantity - $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *;
    `;
    try {
      const result = await pool.query(query, [quantity, productId]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error updating stock: ${err.message}`);
    }
  }
}

module.exports = Product;
