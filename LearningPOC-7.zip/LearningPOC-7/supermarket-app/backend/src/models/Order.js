const pool = require('../config/database');

class Order {
  static async createTable() {
    const queries = [
      `
        CREATE TABLE IF NOT EXISTS orders (
          id SERIAL PRIMARY KEY,
          user_id INTEGER NOT NULL,
          total_amount DECIMAL(10, 2) NOT NULL,
          status VARCHAR(50) DEFAULT 'pending',
          payment_method VARCHAR(50),
          payment_status VARCHAR(50) DEFAULT 'pending',
          delivery_address TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id)
        );
      `,
      `
        CREATE TABLE IF NOT EXISTS order_items (
          id SERIAL PRIMARY KEY,
          order_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          quantity INTEGER NOT NULL,
          unit_price DECIMAL(10, 2) NOT NULL,
          total_price DECIMAL(10, 2) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (order_id) REFERENCES orders(id),
          FOREIGN KEY (product_id) REFERENCES products(id)
        );
      `
    ];
    const client = await pool.connect();
    try {
      for (const query of queries) {
        await client.query(query);
      }
      console.log('Orders tables created successfully');
    } catch (err) {
      console.error('Error creating orders tables:', err);
    } finally {
      client.release();
    }
  }

  static async create(userId, items, totalAmount, deliveryAddress) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      // Create order
      const orderQuery = `
        INSERT INTO orders (user_id, total_amount, delivery_address)
        VALUES ($1, $2, $3)
        RETURNING *;
      `;
      const orderResult = await client.query(orderQuery, [userId, totalAmount, deliveryAddress]);
      const order = orderResult.rows[0];

      // Create order items
      const itemsQuery = `
        INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING *;
      `;

      for (const item of items) {
        await client.query(itemsQuery, [
          order.id,
          item.productId,
          item.quantity,
          item.unitPrice,
          item.totalPrice
        ]);
      }

      await client.query('COMMIT');
      return order;
    } catch (err) {
      await client.query('ROLLBACK');
      throw new Error(`Error creating order: ${err.message}`);
    } finally {
      client.release();
    }
  }

  static async getById(orderId) {
    const query = `
      SELECT o.*, 
        json_agg(json_build_object(
          'id', oi.id, 
          'product_id', oi.product_id, 
          'quantity', oi.quantity, 
          'unit_price', oi.unit_price, 
          'total_price', oi.total_price
        )) as items
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      WHERE o.id = $1
      GROUP BY o.id;
    `;
    try {
      const result = await pool.query(query, [orderId]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error fetching order: ${err.message}`);
    }
  }

  static async getByUserId(userId, limit = 50, offset = 0) {
    const query = `
      SELECT o.*, 
        json_agg(json_build_object(
          'id', oi.id, 
          'product_id', oi.product_id, 
          'quantity', oi.quantity, 
          'unit_price', oi.unit_price, 
          'total_price', oi.total_price
        )) as items
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      WHERE o.user_id = $1
      GROUP BY o.id
      ORDER BY o.created_at DESC
      LIMIT $2 OFFSET $3;
    `;
    try {
      const result = await pool.query(query, [userId, limit, offset]);
      return result.rows;
    } catch (err) {
      throw new Error(`Error fetching user orders: ${err.message}`);
    }
  }

  static async updateStatus(orderId, status) {
    const query = `
      UPDATE orders
      SET status = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *;
    `;
    try {
      const result = await pool.query(query, [status, orderId]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error updating order status: ${err.message}`);
    }
  }

  static async updatePaymentStatus(orderId, paymentStatus) {
    const query = `
      UPDATE orders
      SET payment_status = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *;
    `;
    try {
      const result = await pool.query(query, [paymentStatus, orderId]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error updating payment status: ${err.message}`);
    }
  }
}

module.exports = Order;
