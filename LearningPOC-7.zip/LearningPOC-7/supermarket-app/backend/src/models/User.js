const pool = require('../config/database');
const bcrypt = require('bcryptjs');

class User {
  static async createTable() {
    const query = `
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        phone_number VARCHAR(15) UNIQUE NOT NULL,
        otp VARCHAR(6),
        otp_expires_at TIMESTAMP,
        is_verified BOOLEAN DEFAULT false,
        first_name VARCHAR(100),
        last_name VARCHAR(100),
        email VARCHAR(255) UNIQUE,
        address TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;
    const client = await pool.connect();
    try {
      await client.query(query);
      console.log('Users table created successfully');
    } catch (err) {
      console.error('Error creating users table:', err);
    } finally {
      client.release();
    }
  }

  static async create(phoneNumber, firstName, lastName) {
    const query = `
      INSERT INTO users (phone_number, first_name, last_name)
      VALUES ($1, $2, $3)
      RETURNING id, phone_number, first_name, last_name, created_at;
    `;
    try {
      const result = await pool.query(query, [phoneNumber, firstName, lastName]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error creating user: ${err.message}`);
    }
  }

  static async findByPhoneNumber(phoneNumber) {
    const query = 'SELECT * FROM users WHERE phone_number = $1;';
    try {
      const result = await pool.query(query, [phoneNumber]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error finding user: ${err.message}`);
    }
  }

  static async findById(id) {
    const query = 'SELECT * FROM users WHERE id = $1;';
    try {
      const result = await pool.query(query, [id]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error finding user: ${err.message}`);
    }
  }

  static async updateOTP(phoneNumber, otp) {
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
    const query = `
      UPDATE users
      SET otp = $1, otp_expires_at = $2, updated_at = CURRENT_TIMESTAMP
      WHERE phone_number = $3
      RETURNING *;
    `;
    try {
      const result = await pool.query(query, [otp, expiresAt, phoneNumber]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error updating OTP: ${err.message}`);
    }
  }

  static async verifyUser(phoneNumber) {
    const query = `
      UPDATE users
      SET is_verified = true, updated_at = CURRENT_TIMESTAMP
      WHERE phone_number = $1
      RETURNING *;
    `;
    try {
      const result = await pool.query(query, [phoneNumber]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error verifying user: ${err.message}`);
    }
  }

  static async updateProfile(userId, firstName, lastName, email, address) {
    const query = `
      UPDATE users
      SET first_name = $1, last_name = $2, email = $3, address = $4, updated_at = CURRENT_TIMESTAMP
      WHERE id = $5
      RETURNING *;
    `;
    try {
      const result = await pool.query(query, [firstName, lastName, email, address, userId]);
      return result.rows[0];
    } catch (err) {
      throw new Error(`Error updating user profile: ${err.message}`);
    }
  }
}

module.exports = User;
