require('dotenv').config();
const User = require('../models/User');
const Product = require('../models/Product');
const Order = require('../models/Order');
const pool = require('../config/database');

const runMigrations = async () => {
  try {
    console.log('Starting database migrations...');

    await User.createTable();
    await Product.createTable();
    await Order.createTable();

    // Insert sample products
    await seedProducts();

    console.log('Migrations completed successfully!');
    pool.end();
  } catch (err) {
    console.error('Migration error:', err);
    pool.end();
    process.exit(1);
  }
};

const seedProducts = async () => {
  const products = [
    {
      name: 'Fresh Apples',
      description: 'Organic red apples',
      price: 5.99,
      stockQuantity: 100,
      category: 'Fruits',
      imageUrl: 'https://via.placeholder.com/200?text=Apples'
    },
    {
      name: 'Milk Carton',
      description: 'Fresh whole milk 1L',
      price: 3.29,
      stockQuantity: 50,
      category: 'Dairy',
      imageUrl: 'https://via.placeholder.com/200?text=Milk'
    },
    {
      name: 'Whole Wheat Bread',
      description: 'Nutritious whole wheat bread',
      price: 2.99,
      stockQuantity: 75,
      category: 'Bakery',
      imageUrl: 'https://via.placeholder.com/200?text=Bread'
    },
    {
      name: 'Chicken Breast',
      description: 'Fresh boneless chicken breast',
      price: 8.99,
      stockQuantity: 40,
      category: 'Meat',
      imageUrl: 'https://via.placeholder.com/200?text=Chicken'
    },
    {
      name: 'Broccoli',
      description: 'Fresh green broccoli',
      price: 3.49,
      stockQuantity: 60,
      category: 'Vegetables',
      imageUrl: 'https://via.placeholder.com/200?text=Broccoli'
    },
    {
      name: 'Orange Juice',
      description: 'Fresh squeezed orange juice',
      price: 4.99,
      stockQuantity: 80,
      category: 'Beverages',
      imageUrl: 'https://via.placeholder.com/200?text=Orange+Juice'
    }
  ];

  const query = `
    INSERT INTO products (name, description, price, stock_quantity, category, image_url)
    VALUES ($1, $2, $3, $4, $5, $6)
    ON CONFLICT DO NOTHING;
  `;

  try {
    for (const product of products) {
      await pool.query(query, [
        product.name,
        product.description,
        product.price,
        product.stockQuantity,
        product.category,
        product.imageUrl
      ]);
    }
    console.log('Sample products inserted successfully');
  } catch (err) {
    console.error('Error seeding products:', err);
  }
};

runMigrations();
